﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;


namespace inventorystockmanagementsystem
{
    public partial class vendor : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public vendor()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider = Microsoft.Jet.OLEDB.4.0; Data Source = C:\Users\zaid1\Desktop\Stock\DB\Stock.mdb";
        }

        

        private void vendor_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'vendorDataSet.vendor' table. You can move, or remove it, as needed.
            this.vendorTableAdapter.Fill(this.vendorDataSet.vendor);



        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "delete from vendor where  ID = " + txt_vendorID.Text + " ";
                command.ExecuteNonQuery();
                MessageBox.Show("Data Deleted");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void companyMstBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.companyMstBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stockDataSet);

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "insert into vendor (ID, vendorName, Address, ContactName, Contact) values('" + txt_vendorID.Text + "','" + txt_vendorName.Text + "', '" + txt_vendorAddress.Text + "', '" + txt_ContactName.Text + "', '" + txt_PhoneNumebr.Text + "' ) ";
                command.ExecuteNonQuery();
                MessageBox.Show("Data Saved");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "select * from vendor";
                command.CommandText = query;

                OleDbDataAdapter da = new OleDbDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "update vendor set vendorName = '" + txt_vendorName.Text + "', Address = '" + txt_vendorAddress.Text + "', ContactName = '" + txt_ContactName.Text + "', Contact = '" + txt_PhoneNumebr.Text + "' where ID = " + txt_vendorID.Text + " ";
                MessageBox.Show(query);
                command.CommandText = query;

                command.ExecuteNonQuery();
                MessageBox.Show("Data Edit Successfully!");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_vendorID.Text = "";
            txt_vendorName.Clear();
            txt_vendorAddress.Clear();
            txt_ContactName.Clear();
            txt_PhoneNumebr.Clear();
          
        }
    }
}
