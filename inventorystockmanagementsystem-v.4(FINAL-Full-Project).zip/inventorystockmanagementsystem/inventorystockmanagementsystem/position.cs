﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;


namespace inventorystockmanagementsystem
{
    public partial class position : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public position()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider = Microsoft.Jet.OLEDB.4.0; Data Source = C:\Users\zaid1\Desktop\Stock\DB\Stock.mdb";
        }

        private void position_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'positionStockDataSet.position' table. You can move, or remove it, as needed.
            this.positionTableAdapter.Fill(this.positionStockDataSet.position);

        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "select * from position";
                command.CommandText = query;

                OleDbDataAdapter da = new OleDbDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "insert into position (positionID, positionName, employeeID) values('" + txt_positionID.Text + "','" + txt_positionName.Text + "' , '" + txt_employeeID.Text + "') ";
                command.ExecuteNonQuery();
                MessageBox.Show("Data Saved");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_View_Click_1(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "select * from position";
                command.CommandText = query;

                OleDbDataAdapter da = new OleDbDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "delete from position where  positionID = " + txt_positionID.Text + " ";
                command.ExecuteNonQuery();
                MessageBox.Show("Data Deleted");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "update position set positionName = '" + txt_positionName.Text + "', employeeID = '" + txt_employeeID.Text + "',  where positionID = " + txt_positionID.Text + "";
                MessageBox.Show(query);
                command.CommandText = query;

                command.ExecuteNonQuery();
                MessageBox.Show("Data Edit Successfully!");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txt_positionID.Text = "";
            txt_positionName.Clear();
            txt_employeeID.Clear();

        }
    }
    
}
