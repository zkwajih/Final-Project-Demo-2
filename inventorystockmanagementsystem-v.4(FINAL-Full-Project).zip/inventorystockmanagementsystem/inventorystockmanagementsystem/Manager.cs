﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;


namespace inventorystockmanagementsystem
{
    public partial class Manager : Form
    {
        private OleDbConnection connection = new OleDbConnection();

        public Manager()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider = Microsoft.Jet.OLEDB.4.0; Data Source = C:\Users\zaid1\Desktop\Stock\DB\Stock.mdb";
        }

        private void txt_employeeID_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Manager_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'managerStockDataSet.manager' table. You can move, or remove it, as needed.
            

        }

        private void btn_View_Click(object sender, EventArgs e)
        {

            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "select * from manager";
                command.CommandText = query;

                OleDbDataAdapter da = new OleDbDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "insert into manager (managerID, managerFirstName, managerLastName, managerAddress, city, state, Zip, ContactNumber) values('" + txt_managerID.Text + "','" + txt_managerFirstName.Text + "' , '" + txt_managerLastName.Text + "', '" + txt_managerAddress.Text + "', '" + txt_city.Text + "', '" + txt_st.Text + "', '" + txt_zip.Text + "','" + txt_contactNumber.Text + "' ) ";
                command.ExecuteNonQuery();
                MessageBox.Show("Data Saved");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "delete from manager where  managerID = " + txt_managerID.Text + " ";
                command.ExecuteNonQuery();
                MessageBox.Show("Data Deleted");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "update manager set managerFirstName = '" + txt_managerFirstName.Text + "', managerLastName = '" + txt_managerLastName.Text + "', managerAddress = '" + txt_managerAddress.Text + "', city = '" + txt_city.Text + "', state = '" + txt_st.Text + "', Zip = '" + txt_zip.Text + "', ContactNumber = '" + txt_contactNumber.Text + "' where managerID = "+txt_managerID.Text+"";
                MessageBox.Show(query);
                command.CommandText = query;

                command.ExecuteNonQuery();
                MessageBox.Show("Data Edit Successfully!");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txt_managerID.Text = "";
            txt_managerFirstName.Clear();
            txt_managerLastName.Clear();
            txt_managerAddress.Clear();
            txt_city.Clear();
            txt_st.Clear();
            txt_zip.Clear();
            txt_contactNumber.Clear();
        }
    }
}