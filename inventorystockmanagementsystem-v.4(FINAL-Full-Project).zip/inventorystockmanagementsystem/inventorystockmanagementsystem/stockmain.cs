﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace inventorystockmanagementsystem
{
    public partial class stockmain : Form
    {

        public stockmain()
        {
            InitializeComponent();
        }

        private void stockmain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            product pro = new product();
            pro.MdiParent = this;
            pro.Show();

        }

        private void vendorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            vendor ven = new vendor();
            ven.MdiParent = this;
            ven.Show();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            employee emp = new employee();
            emp.MdiParent = this;
            emp.Show();
            
        }

        private void postionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            position pos = new position();
            pos.MdiParent = this;
            pos.Show();
        }

        private void manageUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
               
            
        }

        private void managerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manager mgr = new Manager();
            mgr.MdiParent = this;
            mgr.Show();
        }
    }
}
