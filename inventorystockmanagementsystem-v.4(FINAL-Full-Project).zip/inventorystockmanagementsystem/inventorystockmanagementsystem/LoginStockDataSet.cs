﻿namespace inventorystockmanagementsystem
{


    partial class LoginStockDataSet
    {
    }
}

namespace inventorystockmanagementsystem.LoginStockDataSetTableAdapters {
    
    
    public partial class LoginTableAdapter {
    }
}
